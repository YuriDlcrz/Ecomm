<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:user_login.php');
};

if(isset($_POST['order'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $method = $_POST['method'];
   $method = filter_var($method, FILTER_SANITIZE_STRING);
   $address = 'flat no. '. $_POST['flat'] .', '. $_POST['street'] .', '. $_POST['city'] .', '. $_POST['state'] .', '. $_POST['country'] .' - '. $_POST['pin_code'];
   $address = filter_var($address, FILTER_SANITIZE_STRING);
   $total_products = $_POST['total_products'];
   $total_price = $_POST['total_price'];

   $check_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
   $check_cart->execute([$user_id]);

   if($check_cart->rowCount() > 0){

      $insert_order = $conn->prepare("INSERT INTO `orders`(user_id, name, number, email, method, address, total_products, total_price) VALUES(?,?,?,?,?,?,?,?)");
      $insert_order->execute([$user_id, $name, $number, $email, $method, $address, $total_products, $total_price]);

      $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
      $delete_cart->execute([$user_id]);

      $message[] = 'order placed successfully!';
   }else{
      $message[] = 'your cart is empty';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>checkout</title>
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="checkout-orders">
    <form action="" method="POST" onsubmit="return validateForm()">

        <h3>your orders</h3>

        <div class="display-orders">
            <?php
            $grand_total = 0;
            $cart_items = []; // Initialize an empty array for cart items
            $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
            $select_cart->execute([$user_id]);
            if($select_cart->rowCount() > 0){
                while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
                    $sub_total = $fetch_cart['price'] * $fetch_cart['quantity'];
                    $grand_total += $sub_total;
                    $cart_items[] = [
                        'id' => $fetch_cart['id'],
                        'name' => $fetch_cart['name'],
                        'price' => $fetch_cart['price'],
                        'quantity' => $fetch_cart['quantity'],
                        'sub_total' => $sub_total
                    ];
                    ?>
                    <div class="order-item">
                        <p><?= $fetch_cart['name']; ?> <span>(<?= '$'.$fetch_cart['price'].'/- x '. $fetch_cart['quantity']; ?>)</span></p>
                        
                    </div>
                    <?php
                }
            } else {
                echo '<p class="empty">your cart is empty!</p>';
            }
            ?>
            <input type="hidden" name="total_products" value="<?= htmlspecialchars(json_encode($cart_items)); ?>">
            <div class="grand-total">grand total : <span>$<?= $grand_total; ?>/-</span></div>
        </div>

        <h3>place your orders</h3>

        <div class="flex">
            <div class="inputBox">
                <span>your name :</span>
                <input type="text" name="name" placeholder="" class="box" maxlength="20" >
                <div class="error-message" id="error-name"></div>
            </div>
            <div class="inputBox">
                <span>your number :</span>
                <input type="number" name="number" placeholder="" class="box" min="0" max="9999999999" onkeypress="if(this.value.length == 10) return false;" >
                <div class="error-message" id="error-number"></div>
            </div>
            <div class="inputBox">
                <span>your email :</span>
                <input type="email" name="email" placeholder="" class="box" maxlength="50" >
                <div class="error-message" id="error-email"></div>
            </div>
            <div class="inputBox">
                <span>payment method :</span>
                <select name="method" class="box" >
                    <option value="cash on delivery">cash on delivery</option>
                    <option value="credit card">credit card</option>
                    <option value="paytm">paytm</option>
                    <option value="paypal">paypal</option>
                </select>
                <div class="error-message" id="error-method"></div>
            </div>
            <div class="inputBox">
                <span>address line 01 :</span>
                <input type="text" name="flat" placeholder="" class="box" maxlength="50" >
                <div class="error-message" id="error-flat"></div>
            </div>
            <div class="inputBox">
                <span>address line 02 :</span>
                <input type="text" name="street" placeholder="" class="box" maxlength="50" >
                <div class="error-message" id="error-street"></div>
            </div>
            <div class="inputBox">
                <span>city :</span>
                <input type="text" name="city" placeholder="" class="box" maxlength="50" >
                <div class="error-message" id="error-city"></div>
            </div>
            <div class="inputBox">
                <span>barangay :</span>
                <input type="text" name="state" placeholder="" class="box" maxlength="50" >
                <div class="error-message" id="error-state"></div>
            </div>
            <div class="inputBox">
                <span>country :</span>
                <input type="text" name="country" placeholder="" class="box" maxlength="50" >
                <div class="error-message" id="error-country"></div>
            </div>
            <div class="inputBox">
                <span>pin code :</span>
                <input type="number" min="0" name="pin_code" placeholder="" min="0" max="999999" onkeypress="if(this.value.length == 6) return false;" class="box" >
                <div class="error-message" id="error-pin_code"></div>
            </div>
        </div>

        <input type="submit" name="order" class="btn <?= ($grand_total > 1) ? '' : 'disabled'; ?>" value="place order">

    </form>
</section>

<script>
    function validateForm() {
        let isValid = true;

        const fields = [
            { name: 'name', message: 'Please enter your name.' },
            { name: 'number', message: 'Please enter your number.' },
            { name: 'email', message: 'Please enter your email.' },
            { name: 'method', message: 'Please select a payment method.' },
            { name: 'flat', message: 'Please enter address line 01.' },
            { name: 'street', message: 'Please enter address line 02.' },
            { name: 'city', message: 'Please enter your city.' },
            { name: 'state', message: 'Please enter your barangay.' },
            { name: 'country', message: 'Please enter your country.' },
            { name: 'pin_code', message: 'Please enter your pin code.' },
        ];

        fields.forEach(field => {
            const input = document.querySelector(`[name="${field.name}"]`);
            const errorElement = document.getElementById(`error-${field.name}`);

            if (!input.value.trim()) {
                errorElement.textContent = field.message;
                isValid = false;
            } else {
                errorElement.textContent = '';
            }
        });

        return isValid;
    }
</script>

<style>
    .error-message {
        color: red;
        font-size: 1.875em;
        margin-top: 0.25em;
    }
</style>













<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>